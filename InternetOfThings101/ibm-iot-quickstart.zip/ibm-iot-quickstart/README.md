iot-GW-solutions
===========

This is a sample client for Intel Gateway Solutions for the IoT development kits

Using the this code and the recipe at https://developer.ibm.com/iot/recipes/
you can run a python script to send cpu utilisation data to the IBM Internet of Things Foundation 
service at http://internetofthings.ibmcloud.com

This is a work in progress.
