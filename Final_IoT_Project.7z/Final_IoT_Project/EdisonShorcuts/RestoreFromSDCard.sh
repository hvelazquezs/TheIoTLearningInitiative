dd if=/media/sdcard/edison_backup.img of=/dev/mmcblk0
