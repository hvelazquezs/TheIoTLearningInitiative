sudo umount /media/flashdrive/



