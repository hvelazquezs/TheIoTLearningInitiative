dd if=/dev/mmcblk0 of=/media/sdcard/edison_backup.img
