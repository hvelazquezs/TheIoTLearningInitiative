mkdir /media/flashdrive

mount /dev/sda1 /media/flashdrive


