cd /

umount /update

modprobe g_multi
